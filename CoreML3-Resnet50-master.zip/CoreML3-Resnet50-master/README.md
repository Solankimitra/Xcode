# CoreML3-Resnet50

# License
MIT
